#XAVI


# Load libraries

library(shiny)
library(shinyWidgets)
library(tidyverse)
library(tidytext)
library(wordcloud2)
library(lubridate)
library(tools)
library(scales)
library(ggforce)
library(zoo)
library(DT)
library(plotly)
library(RColorBrewer)
library(igraph) 
library(ggraph) 
library(rsconnect)
library(shinyjs)
library(textdata)
library(tippy)
library(waiter)


# Read tweets data
data <- read.csv("https://raw.githubusercontent.com/xavivg91/shiny-contest-2021/main/Data/trump.csv",
                 encoding = "UTF-8", sep = ',') %>%
  mutate_at(vars(target), factor) %>%
  rename(" "="X")


# Read unigrams, bigrams and trigrams data
ngrams <- read.csv("https://raw.githubusercontent.com/xavivg91/shiny-contest-2021/main/Data/ngrams.csv",
                   encoding = "UTF-8", sep = ',') %>%
  mutate_at(vars(target), factor)

# Correct astrange characters
ngrams$word <- iconv(ngrams$word, to = "UTF-8")

# Uppercase 
ngrams$target <- toTitleCase(str_replace_all(ngrams$target, "-", " "))

# Dates
data$date <- as.Date(data$date, format = "%Y-%m-%d")
ngrams$date <- as.Date(ngrams$date, format = "%Y-%m-%d")
ngrams$month <- as.Date(ngrams$month, format = "%Y-%m-%d")
ngrams$week <- as.Date(ngrams$week, format = "%Y-%m-%d")

#Creating a column with "Month Year"
ngrams$textual_date <- as.yearmon(ngrams$month)

#palette
colors <- c("#dd2c00", "#FF712E", "#b2ebf2", "#00bcd4","#dd2c00", "#FF712E", "#b2ebf2", "#00bcd4")

#sentiment
bing <- read.csv("https://raw.githubusercontent.com/xavivg91/shiny-contest-2021/main/Data/bing.csv")
#bing <- get_sentiments("bing")
#write.csv(bing,"C:/Users/xviva/OneDrive/Desktop/bing.csv", row.names = FALSE)

nrc <- read.csv("https://raw.githubusercontent.com/xavivg91/shiny-contest-2021/main/Data/nrc.csv")
#nrc <- get_sentiments("nrc")
#write.csv(nrc,"C:/Users/xviva/OneDrive/Desktop/nrc.csv", row.names = FALSE)


#palette stripes
col_strip <- brewer.pal(11, "YlOrRd")

strips_grey <- (brewer.pal(11, "Greys"))

col_greys <- c("white","#FF9081","#D2ECF5","#C4C4C4", "#919191", "#FE5959", "#FFC7C7", "#96D2E7")


#pretty warming stripes
theme_strip <- theme_minimal()+
  theme(axis.text.y = element_blank(),
        axis.line.y = element_blank(),
        axis.title = element_blank(),
        panel.grid.major = element_blank(),
        legend.title = element_text(color = "white"),
        legend.text = element_text(color = "white"),
        legend.position = "bottom",
        axis.text.x = element_text(vjust = 3, color = "white"),
        panel.grid.minor = element_blank(),
        plot.title = element_text(size = 14, face = "bold", color = "white"),
        panel.background = element_rect(fill = "transparent", color = "transparent"),
        plot.background = element_rect(fill = "transparent", color = NA),
        legend.background = element_rect(fill = "transparent", color = "transparent"),
        legend.box.background = element_rect(fill = "transparent", color = "transparent"),
        strip.text.x = element_text(size = 14, color = "white", face = "bold")
        
  )


# ------------------------------------------------------------------------

# Define UI for application 
ui <-  navbarPage(id = "title", "TRUMP'S ENEMIES NETWORK",
                 # First page home
                 tabPanel("Home", includeCSS("styles.css.css"),
                          tags$head(
                            tags$style(type = 'text/css', 
                                       HTML('
                          
                          .navbar-default .navbar-nav > .active > a, 
                           .navbar-default .navbar-nav > .active > a:focus, 
                           .navbar-default .navbar-nav > .active > a:hover {
                                color: #555;
                                background-color: azure1;
                            }')
                            )
                          ),
                          
                          fluidPage(use_waiter(),
                                    waiter_show_on_load(html = tagList(spin_square_circle(), h3("Loading ...")), color="#B03636"),

                                    column(9,
                                           h1("TRUMP'S", strong("ENEMIES"), "NETWORK", align = "left")),
                                    (column(6,
                                            br(),
                                            br(),
                                            br(),
                                            p("In the beggining of 2021, the expresident of the United States of America", strong("Donald Trump"), "had about 88 milion followers on Twitter. \nTrump is recognized as a pioneer in political communication on Twitter, but he is also recognized for his fake news and direct attacks on anyone who does not like him. On 8th January 2021, Twitter announced they had 'permanently
                            suspended his account (@realDonaldTrump) due to the risk of further incitement of violence'.", align = "left"),
                                            br(),
                                            p("This is a tool for analyzing all the insults he spread through Twitter during 7 years. This is the analysis of his", strong("hate social network."), align = "left"),
                                            br(),
                                            br(),
                                            p(strong(tippy("XAVIER VIVANCOS GARCÍA", tooltip = "Telecommunications Engineer (Pompeu Fabra University, 2016) and Master in Business Intelligence and Big Data (Open University of Catalonia, 2018). 
                                            Currently working as a BI consultant, using data visualization tools  to develop and maintain dashboards.", animation = "scale", duration = 500, placement = "bottom"),   "|",  
                                                     tippy("LAURA NAVARRO SOLER", tooltip=" Data journalist. Graduated in Journalism from Miguel Hernández de Elche University (2017)
                                                     and postgraduate in Data Journalism and Visualization from the Blanquerna University (2019).
                                                           I work as a freelance with an interest in social, environmental and scientific issues.", animation = "scale", duration = 500, placement = "bottom"))
                                                     , align = "center"),
                                            a(href="https://twitter.com/Xavier91vg", "@Xavier91vg  ", align = "center"),
                                            a(href="https://twitter.com/LauraNavarroSol", "  @LauraNavarroSol", align = "center"),
                                            br(),
                                            br(),
                                            br(),
                                            h6("The data used here comes from from the dataset",a(href="https://www.kaggle.com/ayushggarg/all-trumps-twitter-insults-20152021", "All Trump's Twitter insults (2015-2021)"), "by Ayush Garg, found in Kaggle and extracted from The New York Times.", align = "left"),
                                            
                                            
                                            
                                            
                                            
                                    )),
                                    column(4,
                                           div(img(src = "trump_tweet.png", height = 450, width = 550), style="text-align: center;"),
                                           
                                    ))),
                
                # Second tab
                tabPanel("My best insults", icon=icon("comment-dots"), 
                         tags$style(".fa-comment-dots {color:#DD0000}"),
                         
                         fluidPage(useShinyjs(),
                                   sidebarLayout(position = "left", 
                                          sidebarPanel(id="sidebar",
                                                       pickerInput("insult", "The favourite insults: Choose one", 
                                                          choices = c("fake", "sleepy", "crooked", "failing", "witch", "radical",
                                                                      "fraudulent", "corrupt", "crazy", "dishonest", "weak", "bad", "hoax", "disaster", "terrible",
                                                                      "crime", "scam", "loser", "disgrace", "incompetent", "dumb", "false", "ridiculous",
                                                                      "horrible", "mess", "puppet", "boring", "stupid"), 
                                                           options = list(`actions-box` = FALSE , "max-options" = 3), multiple = T,
                                                          selected = "fake",
                                                          choicesOpt = list(
                                                            style = rep(("color: grey;"),28))),
                                                       
                                                       dateRangeInput('dateRange',
                                                                             label = 'Date range input: yyyy-mm-dd',
                                                                             start = "2014-10-09", end = "2021-01-06",
                                                                             min = "2014-10-09", max = "2021-01-06"),
                                                       
                                                       conditionalPanel(condition = "input.insult.length > 0",
                                                                        materialSwitch(
                                                                          inputId = "Id078",
                                                                          label = "Compare with the total of insults", 
                                                                          value = FALSE,
                                                                          status = "primary"
                                                                        )),
                                                       div(style="display:center-align", actionButton("reset1", "Reset date", icon=icon("filter"),
                                                                    style='padding:4px; font-size:80%')),
                                                       column(7,
                                                              br(),
                                                              br(),
                                                              br(),
                                                              br(),
                                                              p("Scroll down to see the network", align = "left"),
                                                              div(img(src = "flecha.png", height = 170, width = 100)))
                                                       
                                                 ),
                                                 
                                                 # Show a plot 
                                                 mainPanel(
                                                   p(strong("Select from the most used insults by Donald Trump and see when he said them")),
                                                   p("Try to select an area of the graph to take a closer look"),
                                                   br(),
                                                   plotlyOutput("plot1"),
                                                   br(),
                                                   br(),
                                                   p(strong("This network shows all the words related to the one/s selected")),
                                                   p("The darker the arrow, the more related and more times are used the connected words"),
                                                   br(),
                                                   plotOutput("networkinsults")
                                                 ))
                         )
                
                     ),



                  # Third tab
                    tabPanel("My top enemies", icon=icon("poo"),
                             tags$style(".fa-poo {color:#DD0000}"),
                             
                             fluidPage(
                               sidebarLayout(position = "left",
                                             sidebarPanel(id="sidebar",
                                                          pickerInput("enemy", "Main enemies: Choose one to compare", 
                                                                      choices = c("Cnn", "Democrats", "Hillary Clinton", 
                                                                                  "Impeachment Inquiry", "Joe Biden",
                                                                                  "The Media", "The New York Times", "Trump Russia"), 
                                                                      options = list(`actions-box` = TRUE), multiple = T,
                                                                      selected = "Cnn",
                                                                      choicesOpt = list(
                                                                        style = rep(("color: grey;"), 8))),
                                                          
                                                          dateRangeInput('dateRange2',
                                                                         label = 'Date range input: yyyy-mm-dd',
                                                                         start = "2014-10-09", end = "2021-01-06",
                                                                         min = "2014-10-09", max = "2021-01-06"),
                                                          conditionalPanel(condition = "input.enemy.length > 0",
                                                                           materialSwitch(
                                                                             inputId = "Id077",
                                                                             label = "Bigrams (two words)", 
                                                                             value = FALSE,
                                                                             status = "primary"
                                                                           )), 
                                                          div(style="display:center-align", actionButton("reset2", "Reset date", icon=icon("filter"),
                                                                       style='padding:4px; font-size:80%')),
                                                          column(7,
                                                                 br(),
                                                                 br(),
                                                                 br(),
                                                                 br(),
                                                                 div(style="display:center-align", img(src = "boca_2.png", height = 150, width = 150)),
                                                                 br(),
                                                                 div(style="display:center-align", img(src = "boca_3.png", height = 150, width = 150))
                                                                 )
                                                          
                                             ),
                                             
                                             # Show a plot
                                             mainPanel(
                                                    p(strong("Common enemies who Donald Trump dedicated despective tweets")),
                                                    p("Select one or more enemies and check in which months Donald Trump insulted them the most"),
                                                    br(),
                                                    plotlyOutput("plot2"),
                                                    br(),
                                                    br(),
                                                    p(strong("Most common words used in the tweet")),
                                                    p("Which words were most used by Donald Trump when he wrote about his TOP enemies?"),
                                                    br(),
                                                    plotOutput("plot3")   
                                                    )
                                             
                                             
                                             ))),
                # tab events
                tabPanel("Periods", icon=icon("calendar-alt"), 
                         tags$style(".fa-calendar-alt {color:#DD0000}"),
                         
                         fluidPage(useShinyjs(),
                                   sidebarLayout(position = "left", 
                                                 sidebarPanel(id="sidebar",
                                                              
                                                              radioButtons("period", "Select a critical period of time", 
                                                                          choices = c("Presidential Elections 2020", "Black Lives Matter", "Impeachment"), 
                                                                          selected = "Presidential Elections 2020"),
                                                 ),
                                                 
                                                 # Show a plot 
                                                 mainPanel(
                                                   p(strong("Select a period for seeing which enemies he insulted the most")),
                                                   br(),
                                                   plotOutput("plot6"),
                                                   column(7,
                                                          imageOutput("myimage")
                                                   )
                                                   
                                                 ))
                         )
                         
                ),
                
                
                
                # Fourth tab
                tabPanel("Sentiment Index", icon=icon("heart"),
                         tags$style(".fa-heart {color:#DD0000}"),
                         
                         fluidPage(
                           sidebarLayout(position = "left",
                                         sidebarPanel(id="sidebar",
                                                      pickerInput("enemy2", "Sentiment index", 
                                                                  choices = c("Cnn", "Democrats", "Hillary Clinton", 
                                                                              "Impeachment Inquiry", "Joe Biden",
                                                                              "The Media", "The New York Times", "Trump Russia"), 
                                                                  options = list(`actions-box` = TRUE), multiple = T,
                                                                  selected = "Democrats",
                                                                  choicesOpt = list(
                                                                    style = rep(("color: grey;"),28))),
                                                      
                                                      dateRangeInput('dateRange3',
                                                                     label = 'Date range input: yyyy-mm-dd',
                                                                     start = "2014-10-09", end = "2021-01-06",
                                                                     min = "2014-10-09", max = "2021-01-06"),
                                                      actionButton("reset3", "Reset date", icon=icon("filter"),
                                                                   style='padding:4px; font-size:80%')
                                         ),
                                         
                                         # Show a plot
                                         mainPanel(
                                           p("When humans read a text, we try to infer whether a section of text is", 
                                             strong("positive"), 
                                             "or", 
                                             strong("negative"), 
                                             "or some other more nuanced emotion like surprise or disgust. \n We can use programatically tools, such as", 
                                             strong("text mining"), 
                                             "to approach the emotional content of a text "),
                                           br(),
                                           p("In this case we've used 'tidytext' package, which",
                                             strong("scores for positive/negative sentiment."),
                                             "The lower the index, the greater the negative charge."),
                                           br(),
                                           plotOutput("plot4", width = "100%", height = "225px",),
                                           br(),
                                           p(strong("What kind of words does Donald Trump say to his enemies?")),
                                           br(),
                                           plotOutput("plot_sentiment")
                                        
                                         )
                                         
                                         
                           ))),

                  # Fifth tab
                    tabPanel(id="sidebar",
                             "My Twitter historial", icon=icon("table"), 
                             tags$style(".fa-table {color:#DD0000}"),
                      
                                    DT::dataTableOutput("table") 
                             
                           
         
))

# ------------------------------------------------------------------------------------


# Define server logic 
server <- function(input, output) {
  Sys.sleep(3) # do something that takes time
  waiter_hide()
  
  output$plot1 <- renderPlotly({
    if(input$Id078 == FALSE){
      
      validate(
        need(input$insult, " ")
      )
      
      highlighted <- ngrams %>%
        filter(date >= input$dateRange[1],  date <= input$dateRange[2],
               word %in% input$insult) %>%
        group_by(month, word) %>%
        summarize(total = sum(n))
      
      #unhighlighted <- ngrams %>%
      #filter(date >= input$dateRange[1],  date <= input$dateRange[2]) %>%
      #group_by(month) %>%
      #summarise(total = sum(n))
      
      
      first <-  ggplot(NULL, aes(x = month, y = total, fill = word)) +
        geom_bar(data=highlighted, stat = "identity") +
        #geom_bar(data=unhighlighted, stat = "identity", 
        #         fill = "steelblue", alpha = 0.3) +
        scale_x_date(
          labels = date_format("%b %Y"),
          breaks = "6 month")  +
        scale_fill_manual(values = col_greys) +
        theme_minimal() +
        theme(panel.grid = element_blank(),
              axis.title.x = element_blank(),
              axis.title.y= element_blank(),
              legend.title = element_blank(),
              axis.text.x = element_text(size=7, color = "white"),
              axis.text.y = element_text(size=9, color = "white"),
              legend.text = element_text(color = "white"),
              panel.background = element_rect(fill = "transparent"),
              plot.background = element_rect(fill = "transparent", color = NA),
              legend.background = element_rect(fill = "transparent"),
              legend.box.background = element_rect(fill = "transparent"))
      
      first %>%
        ggplotly() %>% 
        config(displayModeBar = F, displaylogo = FALSE) %>%
        layout(legend = list(orientation = "h", x = 0.3, y = -0.2))
      
    } else if(input$Id078 == TRUE){
      
      validate(
        need(input$insult, " ")
      )
      
      highlighted <- ngrams %>%
        filter(date >= input$dateRange[1],  date <= input$dateRange[2],
               word %in% input$insult,
               type=="unigram") %>%
        group_by(month, word) %>%
        summarize(total = sum(n))
      
      unhighlighted <- ngrams %>%
      filter(date >= input$dateRange[1],  date <= input$dateRange[2],
             type=="unigram") %>%
      group_by(month) %>%
      summarise(total = sum(n))
      
      
      first <-  ggplot(NULL, aes(x = month, y = total, fill="white")) +
        geom_bar(data=highlighted, stat = "identity", show.legend = FALSE) +
        geom_bar(data=unhighlighted, stat = "identity", 
                 fill = "steelblue", alpha = 0.3, show.legend = FALSE) +
        scale_x_date(
          labels = date_format("%b %Y"),
          breaks = "6 month")  +
        scale_fill_manual(values = col_greys) +
        theme_minimal() +
        theme(panel.grid = element_blank(),
              axis.title.x = element_blank(),
              axis.title.y= element_blank(),
              legend.title = element_blank(),
              axis.text.x = element_text(size=7, color = "white"),
              axis.text.y = element_text(size=9, color = "white"),
              legend.text = element_text(color = "white"),
              panel.background = element_rect(fill = "transparent"),
              plot.background = element_rect(fill = "transparent", color = NA),
              legend.background = element_rect(fill = "transparent"),
              legend.box.background = element_rect(fill = "transparent"),
              legend.position='none')
      
      first %>%
        ggplotly() %>% 
        config(displayModeBar = F, displaylogo = FALSE) 
    }
  })
  
  
  
  
  output$networkinsults <- renderPlot({  
    
    validate(
      need(input$insult, " ")
    )
    
   network <- ngrams %>%
      filter(date >= input$dateRange[1],  date <= input$dateRange[2],
             type == "bigram") %>%
      separate(word, c("word1", "word2"), sep=" ") %>%
      filter(word1 == input$insult | word2 == input$insult) %>%
      select(word1, word2, n) %>%
      group_by(word1, word2) %>%
      summarise(n = sum(n)) %>%
     
      graph_from_data_frame() 
    
    set.seed(2016)
    
    # Create and draw arrows 
    a <- grid::arrow(type="closed", length=unit(0.15, "inches"))
    
    # ggraph visualization
  ggraph(network, layout="fr") +
      geom_edge_link(aes(edge_alpha=n), show.legend = FALSE,
                     arrow=a, end_cap=circle(0.07, 'inches')) +
      geom_node_point(color = "white", size=5) +
      geom_node_text(aes(label=name), vjust=1, hjust=1, color = "white") +
      theme_void() +
      theme(
      panel.background = element_rect(fill = "transparent", color = "transparent"),
      plot.background = element_rect(fill = "transparent", color = NA),
      legend.background = element_rect(fill = "transparent"),
      legend.box.background = element_rect(fill = "transparent", color = "transparent")
      )
   
      
  }, bg="transparent")
    
  
  # Plot 2, enemies
  output$plot2 <- renderPlotly({
    

    enemies <- ngrams %>% 
      filter(target %in% input$enemy,
             date >= input$dateRange2[1],  date <= input$dateRange2[2],
             type == "unigram") %>% 
      group_by(target, month) %>% 
      summarize(total = sum(n))
    
    # Prevent error when we don't have any value selected
    validate(
      need(input$enemy, " ")
    )
    
   second <-  ggplot(NULL, aes(x = month, y = total, fill = target)) +
      geom_bar(data = enemies, stat = "identity") +
      scale_x_date(
        labels = date_format("%b %Y"),
        breaks = "2 year")  +
      scale_fill_manual(values = col_greys) +
      facet_wrap(.~target) +
      theme_minimal() +
      theme(panel.grid = element_blank(),
            axis.title.x = element_blank(),
            axis.title.y = element_text(size = 10, color = "white"),
            axis.text.x = element_text(size=9, color = "white"),
            axis.text.y = element_text(size =9, color = "white"),
            legend.position = "none",
            strip.text.x = element_text(size = 14, color = "white", face = "bold"),
            panel.background = element_rect(fill = "transparent", color = "transparent"),
            plot.background = element_rect(fill = "transparent", color = NA),
            legend.background = element_rect(fill = "transparent"),
            legend.box.background = element_rect(fill = "transparent", color = "transparent")
            )
    
   second %>%
     ggplotly() %>% 
     config(displayModeBar = F, displaylogo = FALSE) %>%
     layout(legend = list(orientation = "h", x = 0.3, y = -0.2))
    
  })
  
  output$plot3 <- renderPlot({ 
    
    validate(
      need(input$enemy, " ")
    )
    
      ngrams %>%
        filter(target %in% input$enemy,
               date >= input$dateRange2[1],  date <= input$dateRange2[2],
               type == ifelse(input$Id077 == FALSE, "unigram", "bigram")) %>% 
       group_by(target, word) %>%
       summarise(n = sum(n)) %>%
       filter(!is.na(word)) %>%
       group_by(target) %>%
       top_n(5) %>%
       ggplot(aes(x=reorder(word, n), y=n, fill = target)) +
       geom_col(size=.1) +
       coord_flip() +
        scale_fill_manual(values = col_greys) +
       theme_minimal() +
       facet_wrap(~target, scales="free") +
       labs(x="", y = "number of times") +
        theme(
          axis.text.x = element_text(size=10, color = "white"),
          axis.title = element_text(color = "white"),
          axis.text.y = element_text(size =10, color = "white"),
          panel.grid.minor = element_blank(),
          legend.position = "none",
          panel.background = element_rect(fill = "transparent", color = "transparent"),
          plot.background = element_rect(fill = "transparent", color = NA),
          legend.background = element_rect(fill = "transparent", color = "transparent"),
          legend.box.background = element_rect(fill = "transparent", color = "transparent"),
          strip.text.x = element_text(size = 14, color = "white", face = "bold")
        ) 
        
      
    }, bg = "transparent")
                             
  
  
  #output 4: sentiment index
  
  output$plot4 <- renderPlot({
    
    validate(
      need(input$enemy2, " ")
    )
  
    trump_sentiment <- ngrams %>%
      filter(target %in% input$enemy2,
             date >= input$dateRange3[1],  date <= input$dateRange3[2],
             type == "unigram") %>%
      inner_join(bing) %>%
      count(date, target, sentiment) %>%
      pivot_wider(names_from = sentiment, values_from = n, values_fill = 0) %>% 
      mutate(sentiment = positive - negative)
    
    ggplot(trump_sentiment, aes(date, sentiment, fill = target)) +
      geom_col(show.legend = FALSE) +
      scale_fill_manual(values = col_greys) +
      facet_wrap(~target) +
      theme(
        axis.text.x = element_text(size=10, color = "white"),
        axis.title = element_text(color = "white"),
        axis.text.y = element_text(size =10, color = "white"),
        panel.grid.minor = element_blank(),
        panel.grid = element_line(size=0.2, linetype = "dotted"),
        legend.position = "none",
        panel.background = element_rect(fill = "transparent", color = "transparent"),
        plot.background = element_rect(fill = "transparent", color = NA),
        legend.background = element_rect(fill = "transparent", color = "transparent"),
        legend.box.background = element_rect(fill = "transparent", color = "transparent"),
        strip.text.x = element_text(size = 14, color = "white", face = "bold"),
        strip.background = element_rect(fill="transparent", color = "transparent")
      )

    
  #plot_stripes <- ggplot(trump_sentiment, aes(x = date, y = 1, fill = sentiment))+
   #   geom_tile(show.legend = FALSE)+
    #  scale_x_date(date_breaks = "2 years",
     #              date_labels = "%b %Y")+
      #guides(fill = guide_colorbar())+
      #scale_y_continuous(expand = c(0, 0)) +
      #scale_fill_gradientn(colors = strips_grey)+
      #labs(title = "Sentiment Index of Donald Trump 'insults'") +
      #theme_strip
  
    #ggplotly(plot_stripes) %>% 
    #config(displayModeBar = F, displaylogo = FALSE) %>% 
    #layout(legend = list(orientation = "h", x = 0.4, y = -0.2),
     #      width = 900, height = 200)
  }, bg = "transparent") 
  
  
  #output 5: sentiment index
  
  output$plot5 <- renderPlot({
    
    validate(
      need(input$enemy2, " ")
    )
    
    trump_sentiment <- ngrams %>%
      filter(target %in% input$enemy2,
             date >= input$dateRange3[1],  date <= input$dateRange3[2],
             type == "unigram") %>%
      inner_join(bing) %>%
      count(date, target, sentiment) %>%
      mutate(percentage=)
      spread(sentiment, n, fill = 0) %>%
      mutate(sentiment = positive - negative) %>% 
      mutate(pos = sentiment >= 0)
    
    
    
    ggplot(trump_sentiment, aes(x = date, y = 1, fill = sentiment))+
      geom_tile()+
      scale_x_date(date_breaks = "2 years",
                   date_labels = "%b %Y")+
      guides(fill = guide_colorbar())+
      scale_y_continuous(expand = c(0, 0)) +
      scale_fill_gradientn(colors = strips_grey)+
      labs(title = "Total unigrams / insults") +
      theme_strip +
      theme(
        panel.grid = element_blank()
      )
    
    
  }, height = 170, width = 600, bg="transparent") 
  
  
  
  
  output$plot_sentiment <- renderPlot({ 
    
    validate(
      need(input$enemy2, " ")
    )
    
   ngrams %>% 
      filter(target %in% input$enemy2,
             date >= input$dateRange3[1],  date <= input$dateRange3[2],
             type == "unigram") %>%
     inner_join(nrc, by = c(word = "word")) %>%
      count(sentiment, target, sort = TRUE) %>% 
     group_by(target) %>%
     mutate(percentage=round((n/sum(n)),2)) %>%
     ggplot(aes(x=reorder(sentiment, percentage), y=percentage, fill = target)) +
     geom_col(size=.1) +
     coord_flip() +
     scale_fill_manual(values = col_greys) +
     theme_minimal() +
     facet_wrap(~target) +
     labs(x="", y = "percentage") +
     scale_y_continuous(labels = scales::percent) +
     theme(
       axis.text.x = element_text(size=10, color = "white"),
       axis.title = element_text(color = "white"),
       axis.text.y = element_text(size =10, color = "white"),
       panel.grid.minor = element_blank(),
       legend.position = "none",
       panel.background = element_rect(fill = "transparent", color = "transparent"),
       plot.background = element_rect(fill = "transparent", color = NA),
       legend.background = element_rect(fill = "transparent", color = "transparent"),
       legend.box.background = element_rect(fill = "transparent", color = "transparent"),
       strip.text.x = element_text(size = 14, color = "white", face = "bold")
     ) 
    
      

  }   , bg = "transparent")
  
  
  
  # Plot 6, events
  output$plot6 <- renderPlot({
    
    top_elect <- c("Kamala Harris", "Joe Biden", "Mail in Voting", "Democrats","2020 Election","Nancy Pelosi")
    
    if(input$period == "Presidential Elections 2020"){
      
      
      elections <- ngrams %>% 
        filter(date >= "2020-03-17",  date <= "2020-11-03",
               type == "unigram", target %in% top_elect) %>% 
        group_by(target, month) %>% 
        summarize(total = sum(n))
      
      unhighlighted <- ngrams %>%
        filter(date >= "2020-03-17",  date <= "2020-11-03",
               type == "unigram") %>%
        group_by(month) %>%
        summarise(total = sum(n))
      
      #unhighlighted <- ngrams %>%
      #filter(date >= input$dateRange[1],  date <= input$dateRange[2]) %>%
      #group_by(month) %>%
      #summarise(total = sum(n))
      
      cols_elect <- c("Joe Biden" = "#FF9943", "Other" = "#CD4747", "2020 Election" = "#645F5F", "Kamala Harris" = "#FF6136", "Democrats" = "#79BAD6" ,
                        "Mail in Voting" = "white", "Nancy Pelosi" = "#B8EAFB")
      

      ggplot(NULL, aes(x = month, y = total, fill = target)) +
        geom_bar(data=unhighlighted, stat = "identity", 
                 aes(fill = "Other")) +
        geom_bar(data = elections, stat = "identity") +
        scale_x_date(
          labels = date_format("%b %Y"),
          breaks = "3 month")  +
      scale_fill_manual(values = cols_elect) +
        theme_minimal() +
        theme(panel.grid = element_blank(),
              axis.title.x = element_blank(),
              axis.title.y = element_text(size = 10, color = "white"),
              axis.text.x = element_text(size=9, color = "white"),
              axis.text.y = element_text(size =9, color = "white"),
              strip.text.x = element_text(size = 14, color = "white", face = "bold"),
              panel.background = element_rect(fill = "transparent", color = "transparent"),
              plot.background = element_rect(fill = "transparent", color = NA),
              legend.background = element_rect(fill = "transparent"),
              legend.box.background = element_rect(fill = "transparent", color = "transparent"),
              legend.text = element_text(color = "white"),
              legend.title = element_blank(),
              legend.position = "bottom"
              
        ) +
        annotate(geom = "text", x=as.Date("2020-10-28"), y = 600, 
                 label = "REST\n OF\n INSULTS", 
                 hjust = "left", color = "#EE6565", face = "bold", size = 3) +
        
        annotate(
          geom = "segment", x=as.Date("2020-10-25"), y = 785, xend = as.Date("2020-10-25"), yend = 280,
          arrow = arrow(ends = "both", angle = 90, length = unit(2, "mm")), color = "#EE6565"
        ) +
        
        
        annotate(geom = "text", x=as.Date("2020-02-27"), y = 750, 
                 label = "Donald Trump\nbecomes the presumptive\nRepublican Party nominee", 
                 hjust = "left", color = "white", size = 3.5) +
        
        annotate(
          geom = "curve", x=as.Date("2020-02-24"), y = 725, xend = as.Date("2020-02-27"), yend = 300, 
          curvature = .3, arrow = arrow(length = unit(2, "mm")), color = "white"
        ) +
        annotate(geom = "text", x=as.Date("2020-06-05"), y = 750, 
                 label = "Joe Biden becomes the \npresumptive Democrat Party\nnominee", 
                 hjust = "left", color = "white", size = 3.5) +
        
        annotate(
          geom = "curve", x=as.Date("2020-06-01"), y = 725, xend = as.Date("2020-06-05"), yend = 550, 
          curvature = .2, arrow = arrow(length = unit(2, "mm")), color = "white"
        )
      
    }
    
    else if(input$period == "Black Lives Matter"){
      
      top_blacklives <- c("Joe Biden", "The Media","Fox News", "Democrats","John Bolton", "Twitter", "Brian Kemp")
      
      
      BLM <- ngrams %>% 
        filter(date >= "2020-05-25",  date <= "2021-01-01",
               type == "unigram",
               target %in% top_blacklives) %>% 
        group_by(target, month) %>% 
        summarize(total = sum(n))
      
      unhighlighted <- ngrams %>%
        filter(date >= "2020-05-25",  date <= "2021-01-01",
               type == "unigram") %>%
        group_by(month) %>%
        summarise(total = sum(n))
      
      cols_blives <- c("Joe Biden" = "#FF9943", "Other" = "#CD4747", "John Bolton" = "#645F5F", "Fox News" = "#FF6136", "Democrats" = "#79BAD6",
                       "The Media" = "white", "Nancy Pelosi" = "#B8EAFB", "Twitter" = "#8AEFFF")
      
      ggplot(NULL, aes(x = month, y = total, fill = target)) +
        geom_bar(data=unhighlighted, stat = "identity", 
                 aes(fill = "Other")) +
        geom_bar(data = BLM, stat = "identity") +
        scale_x_date(
          labels = date_format("%b %Y"),
          breaks = "3 month")  +
        scale_fill_manual(values = cols_blives) +
        theme_minimal() +
        theme(panel.grid = element_blank(),
              axis.title.x = element_blank(),
              axis.title.y = element_text(size = 10, color = "white"),
              axis.text.x = element_text(size=9, color = "white"),
              axis.text.y = element_text(size =9, color = "white"),
              strip.text.x = element_text(size = 14, color = "white", face = "bold"),
              panel.background = element_rect(fill = "transparent", color = "transparent"),
              plot.background = element_rect(fill = "transparent", color = NA),
              legend.background = element_rect(fill = "transparent"),
              legend.box.background = element_rect(fill = "transparent", color = "transparent"),
              legend.text = element_text(color = "white"),
              legend.title = element_blank(),
              legend.position = "bottom"
        ) +
        
        annotate(geom = "text", x=as.Date("2020-04-10"), y = 700, 
                 label = "2020-05-25\nGeorge Floyd is killed", 
                 hjust = "left", color = "white", size = 3.5) +
        
        annotate(
          geom = "curve", x=as.Date("2020-04-20"), y = 660, xend = as.Date("2020-04-20"), yend = 220, 
          curvature = .1, arrow = arrow(length = unit(2, "mm")), color = "white"
        ) +
        annotate(geom = "text", x=as.Date("2021-01-04"), y = 600, 
                 label = "REST\n OF\n INSULTS", 
                 hjust = "left", color = "#EE6565", face = "bold", size = 3) +
        
        annotate(
          geom = "segment", x=as.Date("2021-01-01"), y = 790, xend = as.Date("2021-01-01"), yend = 75,
          arrow = arrow(ends = "both", angle = 90, length = unit(2, "mm")), color = "#EE6565"
        )
    }
    
    else if(input$period == "Impeachment"){
      
      
      top_impeachment <- c("Impeachment Inquiry", "Trump Russia", "The Media", "Michael Bloomberg", "Cnn", "Nancy Pelosi")
      
      
      
      impeachment <- ngrams %>% 
        filter(date >= "2020-02-01",  date <= "2021-01-06",
               type == "unigram",
               target %in% top_impeachment) %>% 
        group_by(target, month) %>% 
        summarize(total = sum(n))
      
      unhighlighted <- ngrams %>%
        filter(date >= "2020-02-01",  date <= "2021-03-01",
               type == "unigram") %>%
        group_by(month) %>%
        summarise(total = sum(n))
      
      cols_imp <- c("Other" = "#CD4747", "Impeachment Inquiry" = "#645F5F", "Trump Russia" = "#FF6136", "Michael Bloomberg" = "#79BAD6",
                       "The Media" = "white", "Nancy Pelosi" = "#FF9943", "Cnn" = "#8AEFFF")
      
      ggplot(NULL, aes(x = month, y = total, fill = target)) +
        geom_bar(data=unhighlighted, stat = "identity", 
                 aes(fill = "Other")) +
        geom_bar(data = impeachment, stat = "identity") +
        scale_x_date(
          labels = date_format("%b %Y"),
          breaks = "3 month")  +
        scale_fill_manual(values = cols_imp) +
        theme_minimal() +
        theme(panel.grid = element_blank(),
              axis.title.x = element_blank(),
              axis.title.y = element_text(size = 10, color = "white"),
              axis.text.x = element_text(size=9, color = "white"),
              axis.text.y = element_text(size =9, color = "white"),
              strip.text.x = element_text(size = 14, color = "white", face = "bold"),
              panel.background = element_rect(fill = "transparent", color = "transparent"),
              plot.background = element_rect(fill = "transparent", color = NA),
              legend.background = element_rect(fill = "transparent"),
              legend.box.background = element_rect(fill = "transparent", color = "transparent"),
              legend.text = element_text(color = "white"),
              legend.title = element_blank(),
              legend.position = "bottom"
        ) +
        
        annotate(geom = "text", x=as.Date("2020-01-20"), y = 700, 
                 label = "2020-02-05\nFirst impeachment", 
                 hjust = "left", color = "white", size = 3.5) +
        
        annotate(
          geom = "curve", x=as.Date("2020-01-20"), y = 660, xend = as.Date("2020-01-20"), yend = 570, 
          curvature = .1, arrow = arrow(length = unit(2, "mm")), color = "white", 
        )+
        annotate(geom = "text", x=as.Date("2021-01-24"), y = 600, 
                 label = "REST\n OF\n INSULTS", 
                 hjust = "left", color = "#EE6565", face = "bold", size = 3) +
        
        annotate(
          geom = "segment", x=as.Date("2021-01-20"), y = 790, xend = as.Date("2021-01-20"), yend = 25,
          arrow = arrow(ends = "both", angle = 90, length = unit(2, "mm")), color = "#EE6565"
        )
      
      
      
    }
    
    else if(input$period == "Covid-19"){
      
      
      top_covid <- c("China", "The Media", "Twitter", "2020 Election")
      
      
      
      covid <- ngrams %>% 
        filter(date >= "2020-03-15",  date <= "2021-02-01",
               type == "unigram",
               target %in% top_covid) %>% 
        group_by(target, month) %>% 
        summarize(total = sum(n))
      
      unhighlighted <- ngrams %>%
        filter(date >= "2020-02-01",  date <= "2021-03-01",
               type == "unigram") %>%
        group_by(month) %>%
        summarise(total = sum(n))
      
      
      ggplot(NULL, aes(x = month, y = total, fill = target)) +
        geom_bar(data = impeachment, stat = "identity") +
        geom_bar(data=unhighlighted, stat = "identity", 
                 fill = "steelblue", alpha = 0.3) +
        scale_x_date(
          labels = date_format("%b %Y"),
          breaks = "3 month")  +
        scale_fill_manual(values = c("white","#FF9081","#eeebdd","#C4C4C4", "#919191", "#FE5959", "#FFC7C7", "blue", "black")) +
        #    facet_wrap(.~target) +
        theme_minimal() +
        theme(panel.grid = element_blank(),
              axis.title.x = element_blank(),
              axis.title.y = element_text(size = 10, color = "white"),
              axis.text.x = element_text(size=9, color = "white"),
              axis.text.y = element_text(size =9, color = "white"),
              strip.text.x = element_text(size = 14, color = "white", face = "bold"),
              panel.background = element_rect(fill = "transparent", color = "transparent"),
              plot.background = element_rect(fill = "transparent", color = NA),
              legend.background = element_rect(fill = "transparent"),
              legend.box.background = element_rect(fill = "transparent", color = "transparent"),
              legend.text = element_text(color = "white"),
              legend.title = element_blank(),
              legend.position = "bottom"
        ) +
        
        annotate(geom = "text", x=as.Date("2020-01-20"), y = 700, 
                 label = "2020-02-05\nFirst impeachment", 
                 hjust = "left", color = "white", size = 3.5) +
        
        annotate(
          geom = "curve", x=as.Date("2020-01-20"), y = 660, xend = as.Date("2020-01-20"), yend = 570, 
          curvature = .1, arrow = arrow(length = unit(2, "mm")), color = "white", 
        )
      
      
      
    }
  
    
    
    
  }, bg = "transparent")
  
  #render image period
  
  output$myimage <- renderImage({
   # if(input$period == "Presidential Elections 2020"){
    list(src = "house.png", 
        contentType = 'image/png',
        height = 100, 
        width = 100,
        alt = "Presidential Elections")
  }, deleteFile = FALSE)
    
   # else if(input$period == "Black Lives Matter"){}
  
   # }, deleteFile = FALSE)
    
    

  
  #output table
  output$table = DT::renderDataTable({
    datatable(data, rownames=FALSE) %>% 
      formatStyle(columns=c(" ","date","target", "insult","tweet"),
                  backgroundColor = "#B03636",
                  color="white")  

  })  
  
  
  #reset filters
  observeEvent(input$reset1, {
    reset("dateRange")
  })
  
  observeEvent(input$reset2, {
    reset("dateRange2")
  })
  
  observeEvent(input$reset3, {
    reset("dateRange3")
  })

  
}

# Run the application 
shinyApp(ui = ui, server = server)

